// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  static let ProfileServicesV2DTO = Object(
    typename: "ProfileServicesV2DTO",
    implementedInterfaces: []
  )
}