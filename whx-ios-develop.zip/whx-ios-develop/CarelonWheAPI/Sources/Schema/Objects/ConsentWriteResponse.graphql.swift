// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  static let ConsentWriteResponse = Object(
    typename: "ConsentWriteResponse",
    implementedInterfaces: []
  )
}