// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  static let Query_anthem_auth_config_auth_tokens = Object(
    typename: "query_anthem_auth_config_auth_tokens",
    implementedInterfaces: []
  )
}