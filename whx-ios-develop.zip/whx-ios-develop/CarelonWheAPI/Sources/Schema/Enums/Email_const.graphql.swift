// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum Email_const: String, EnumType {
  case email = "email"
}
