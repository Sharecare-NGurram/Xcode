// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum MutationInput_submitConsentV2_input_consents_items_consent: String, EnumType {
  case yes = "YES"
  case no = "NO"
  case skip = "SKIP"
}
