//
//  StoryboardConstants.swift
//  WHE
//
//  Created by Rajesh Gaddam on 03/03/23.
//

import Foundation
import UIKit

let HealthKitSB = UIStoryboard(name: "PickFocusAreaActive", bundle: nil)
let PrivacySB = UIStoryboard(name: "PrivacyPolicy", bundle: nil)
let MainSB = UIStoryboard(name: "Main", bundle: nil)
let WeeklyPlantSB = UIStoryboard(name: "WeeklyPlanStoryboard", bundle: nil)
