//
//  PrivacyDataModel.swift
//  WHE
//
//  Created by Rajesh Gaddam on 03/03/23.
//

import Foundation

//Data Model integrate when APi is ready
//follow this pattern
//struct PrivacyDataModel: Codable {
//    let privacymessage: String?
//
//    enum CodingKeys: String, CodingKey {
//        case privacymessage = "privacy"
//    }
//}
