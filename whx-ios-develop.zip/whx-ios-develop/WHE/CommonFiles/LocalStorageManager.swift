//
//  LocalStorageManager.swift
//  WHE
//
//  Created by Venkateswarlu Samudrala on 27/02/23.
//
//UserDefultsStoredInformation
import Foundation

private enum LocalStoredKey: String {

    case FTUELetGetStarted = "LetsGetStarted"
    case kAccessToken = "savedToken"
    case FTUELetsGo = "LetsGo"
    case kConfirmEmail = "confirmEmail"
    case trackMedicines = "MedicineSaved"
    case trackMedicinesNotRightNow = "MedicaneNotRightNow"
}

class LocalStorageManager {
    static let defaults = UserDefaults.standard
    
    // set value for GetStarted Screen
    class func setLetsGetStarted(status: Bool) {
        defaults.set(status, forKey: LocalStoredKey.FTUELetGetStarted.rawValue)
    }
    
    // fetch Value
    class func fetchLetsGetStarted() -> Bool {
        return defaults.bool(forKey: LocalStoredKey.FTUELetGetStarted.rawValue)
    }
    
    class func setMedicineSaved(status: Bool) {
         defaults.set(status, forKey: LocalStoredKey.trackMedicines.rawValue)
     }
     
    class func fetchMedicineSaved() -> Bool {
          defaults.bool(forKey: LocalStoredKey.trackMedicines.rawValue)
     }
    
    class func setAccessToken(token: String) {
        defaults.set(token, forKey: LocalStoredKey.kAccessToken.rawValue)
    }
    
    class func fetchAccessToken() -> String {
        return defaults.string(forKey: LocalStoredKey.kAccessToken.rawValue) ?? "123"
    }
    
    class func setLetsGo(status: Bool) {
        defaults.set(status, forKey: LocalStoredKey.FTUELetsGo.rawValue)
    }
    
    class func fetchLetsGo() -> Bool {
        return defaults.bool(forKey: LocalStoredKey.FTUELetsGo.rawValue)
    }
    
    class func setConfirmEmail(status: Bool) {
        defaults.set(status, forKey: LocalStoredKey.kConfirmEmail.rawValue)
    }
    
    class func fetchConfirmEmail() -> Bool {
        return defaults.bool(forKey: LocalStoredKey.kConfirmEmail.rawValue)
    }
  
    class func setTrackMedicinesNotRightNow(status: Bool) {
        defaults.set(status, forKey: LocalStoredKey.trackMedicinesNotRightNow.rawValue)
    }

    class func fetchTrackMedicinesNotRightNow() -> Bool {
        return defaults.bool(forKey: LocalStoredKey.trackMedicinesNotRightNow.rawValue)
    }
}


