//
//  FirstTimeSetupViewController.swift
//  WHE
//
//  Created by Pratima Pundalik on 11/04/23.
//

import UIKit

class FirstTimeSetupViewController: UIViewController {
    @IBOutlet var mainView: UIView!
    
    @IBOutlet weak var moneyReward: UILabel!
    
    @IBOutlet weak var completingTask: UILabel!
    
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var completeStepText: UILabel!
    
    @IBOutlet weak var FirstTimeSetupView: UIView!
    
    @IBOutlet weak var setupFirstWeek: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setGradientBackground()
        applyBGColorCornerRadius()
        applyCornerRadius()
        updateFirstTimeSetupLabels()
    }
    
    @IBAction func setupFirstWeekAction(_ sender: Any) {
        
    }
    
    func applyCornerRadius(){
        setupFirstWeek.layer.cornerRadius = 10
        FirstTimeSetupView.layer.cornerRadius = 10
    }
    
    func updateFirstTimeSetupLabels(){
        moneyReward.text = "You got $10!"
        moneyReward.font = UIFont.semiBold(ofSize: 24)
        moneyReward.textColor = AnthemColor.enabledDateTextColor
        completingTask.text = "For completing your first time setup we added $10 to your balance!"
        completingTask.font = UIFont.mediumBold(ofSize: 16)
        completingTask.textColor = AnthemColor.enabledDateTextColor
        completeStepText.font = UIFont.mediumBold(ofSize: 16)
        completeStepText.textColor = AnthemColor.DayTextColor
        completeStepText.text = "Complete your steps each day to earn ongoing rewards."
        setupFirstWeek.titleLabel?.font = UIFont.semiBold(ofSize: 17)
    }
    
    func applyBGColorCornerRadius() {
        //mainView.layer.cornerRadius = 45
    }

    func setGradientBackground() {
        self.mainView.layer.cornerRadius = 20.0
        self.mainView.clipsToBounds = true
        let colorTop =  UIColor(red: 35.0/255.0, green: 30.0/255.0, blue: 51.0/255.0, alpha: 0.6).cgColor
        let colorBottom = UIColor(red: 35.0/255.0, green: 30.0/255.0, blue: 51.0/255.0, alpha: 0.9).cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop, colorBottom]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.frame = self.view.bounds
        self.gradientView.layer.insertSublayer(gradientLayer, at:0)
    }
}
