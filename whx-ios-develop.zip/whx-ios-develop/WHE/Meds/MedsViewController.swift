//
//  MedsViewController.swift
//  WHE
//
//  Created by Venkateswarlu Samudrala on 19/01/23.
//

import UIKit
import NotificationCenter

protocol AddMedsDetailProtocal : class {
  func selected(info: Int, title: String, moreThanOne: Bool)
}

class MedsViewController: UIViewController {
  @IBOutlet weak var newPrescriptionDescrptionLabel: UILabel!
  @IBOutlet weak var newPrescriptionHeaderTitleLabel: UILabel!
  @IBOutlet weak var notFountPrescriptionConstrain: NSLayoutConstraint!
  @IBOutlet weak var newPrescriptionFoundConstrain: NSLayoutConstraint!
  @IBOutlet weak var prescriptionMainView: UIView!
  @IBOutlet weak var yourMedicationHeaderLable: UILabel!
  @IBOutlet weak var newPrescriptionTableview: UITableView!
  @IBOutlet weak var addPrescriptionButtonOutlet: UIButton!
  @IBOutlet weak var newPrescriptionTableviewHeightConstrain: NSLayoutConstraint!
  @IBOutlet weak var dontAddPrescriptionButtonOutlet: UIButton!
  @IBOutlet weak var nurselineDescrptionLabel: UILabel!
  @IBOutlet weak var scrollViewBG: UIScrollView!
  @IBOutlet weak var scrollviewMainView: UIView!
  @IBOutlet weak var newMedicationDescrptionLabel: UILabel!
  @IBOutlet weak var helpLineView: UIView!
  @IBOutlet weak var addReminderView: UIView!
  @IBOutlet weak var medicationsHeaderTitle: UILabel!
  @IBOutlet weak var reminderView: UIView!
  @IBOutlet weak var addMedsTableview: UITableView!
  @IBOutlet weak var medsCurveView: UIView!
  let id =  UUID().uuidString
  var medicineDataModel = MedicineDataManager()

  @IBOutlet weak var tableviewHeightAnchor: NSLayoutConstraint!
  override func viewDidLoad() {
    super.viewDidLoad()
     
  }
  
  func updatetheMedicinesInfo() -> () {
    medicineDataModel.medicineArray = MedicineDataManager.shared.selectedMedDetails() ?? []
    reloadTableViewData()
  }
  
  override func viewWillAppear(_ animated: Bool) {
    applyBGColorCornerRadius()
    tableViewRegisterNib()
    applyHelpLineViewBoader()
    applyReminderViewCornerRadius()
    applyLineHeightMultipleLabel()
    updatetheMedicinesInfo()
    updateYourMedicationLabelText()
    newPrescriptionViewSetup()
    notificationCenterAddObserver()
  }
  
  func notificationCenterAddObserver() {
    NotificationCenter.default.addObserver(self, selector: #selector(self.updateView), name: UIApplication.didBecomeActiveNotification, object: nil)
  }
 
  @objc func updateView() {
    newPrescriptionViewSetup()
  }
  func applyBGColorCornerRadius() {
    view.backgroundColor = AnthemColor.tabBarDarkGrayColour
    medsCurveView.layer.cornerRadius = 45
    scrollViewBG.layer.cornerRadius = 45
  }
  
  func updateYourMedicationLabelText() {
    yourMedicationHeaderLable.text = medicineDataModel.medicineArray.count <= 0 ?  MedicineDataManager.shared.noMedicationHeaderTitle :  MedicineDataManager.shared.medicationsAppearHeaderTitle
    newMedicationDescrptionLabel.text = medicineDataModel.medicineArray.count <= 0 ?  MedicineDataManager.shared.noMedicationDescription :  MedicineDataManager.shared.medicationsAppearDescription
    newMedicationDescrptionLabel.font =  medicineDataModel.medicineArray.count <= 0 ? UIFont(name: "ElevanceSans-Medium", size: 15) :  UIFont(name: "ElevanceSans-Medium", size: 14)
  }
  
    @IBAction func addReminderButton(_ sender: Any) {
        showReminderScreen()
        
    }
    
    func showReminderScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        if let addReminderController = storyboard.instantiateViewController(withIdentifier: "AddReminderViewController") as? AddReminderViewController {
            addReminderController.reminderTimeDelegate = self
            self.navigationController?.pushViewController(addReminderController, animated: true)
        }
    }
  
  func scheduleNotification(){
    NotificationManager.shared.requestForNotification()
  }
  
  func showNotification(){
    let notificationCenter = UNUserNotificationCenter.current()
    notificationCenter.requestAuthorization(options: [.alert, .sound]) { allowed, error in
      if allowed {
        print("permission granted")
      } else {
        print("error occured ")
      }
      let clearAction = UNNotificationAction(identifier: "ClearNotif", title: "Clear", options: [])
      let category = UNNotificationCategory(identifier: "ClearNotifCategory", actions: [clearAction], intentIdentifiers: [], options: .customDismissAction)
      notificationCenter.setNotificationCategories([category])
      let content = self.getNotificationContent()
      let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 6, repeats: false)
      let request = UNNotificationRequest(identifier: "1008", content: content, trigger: trigger)
      notificationCenter.add(request){ (error) in
        print("Error \(error?.localizedDescription ?? "")")
      }
    }
  }
  
  func getNotificationContent() -> UNMutableNotificationContent {
    let content = UNMutableNotificationContent()
    content.title = NotificationContent.title
    content.body = NotificationContent.body
    content.sound = .default
    content.categoryIdentifier = "ClearNotifCategory"
    return content
  }
  
  func applyLineHeightMultipleLabel() {
    newMedicationDescrptionLabel.attributedText = self.newMedicationDescrptionLabel.updateLineHeightMultipleLabel(with: newMedicationDescrptionLabel.text ?? "")
    nurselineDescrptionLabel.attributedText = self.nurselineDescrptionLabel.updateLineHeightMultipleLabel(with: nurselineDescrptionLabel.text ?? "" , lineHeight: 1.4)
  }
  
  func newPrescriptionViewUpdateLablesMultiline() {
    newPrescriptionDescrptionLabel.attributedText = self.newPrescriptionDescrptionLabel.updateLineHeightMultipleLabel(with: newPrescriptionDescrptionLabel.text ?? "", lineHeight: 1.4 )
    newPrescriptionHeaderTitleLabel.attributedText = self.newPrescriptionHeaderTitleLabel.updateLineHeightMultipleLabel(with: newPrescriptionHeaderTitleLabel.text ?? "" , lineHeight: 1.4)
  }
  
  func applyReminderViewCornerRadius() {
    addReminderView.layer.cornerRadius = 10
  }
  
  func applyHelpLineViewBoader() {
    helpLineView.layer.cornerRadius = 10
    helpLineView.layer.borderWidth = 2
    helpLineView.layer.borderColor = AnthemColor.colorFromHex("#F7F4FF").cgColor
  }
  
  
  @IBAction func callButtonAction(_ sender: Any) {
    yourWeelyPlanVC()
  }
  
  func yourWeelyPlanVC() {
    if let importMedsViewController = WeeklyPlantSB.instantiateViewController(withIdentifier: "YourWeeklyPlanViewController") as? YourWeeklyPlanViewController {
      self.navigationController?.pushViewController(importMedsViewController, animated: true)
    }
  }
  
  @objc func afterThreeSecondsNewPrescriptionViewApperies() {
    newPrescriptionViewAnimation()
  }
  
  func newPrescriptionViewAnimation(isActive: Bool = true, prescriptionviewY: CGFloat = -120, scrollViewMainViewY: CGFloat = -209.0, toastDispaly: Bool = false) {
    self.prescriptionMainView.alpha =  isActive ? 0 : 1
    self.prescriptionMainView.transform = CGAffineTransform(translationX: 1, y: prescriptionviewY)
    self.scrollviewMainView.transform = CGAffineTransform(translationX: 1, y: scrollViewMainViewY)
    newPrescriptionPopUp(isAvaliable:  isActive)
    UIView.animate(withDuration: 2, delay: 0.0, options: .transitionCurlUp, animations: {
      if toastDispaly {
        self.showToast(message: "Added 1 new prescription")
        UserDefaults.standard.set(true, forKey: "newPrescriptionAdded")
      }
      self.prescriptionMainView.alpha = isActive ? 1 : 0
      self.prescriptionMainView.transform = CGAffineTransform(translationX: 1, y: prescriptionviewY == -200 ? prescriptionviewY : 1)
      self.scrollviewMainView.transform = CGAffineTransform(translationX: 1, y: 1)
    }, completion: nil)
  }
  
  func newPrescriptionViewSetup() {
    self.prescriptionMainView.alpha = 0
    self.notFountPrescriptionConstrain.constant = 170
    newPrescriptionPopUp()
    newPrescriptionViewCornerRadiusShadow()
    prescriptionButtonCornerRadius()
    newPrescriptionTableViewRegisterNib()
    newPrescriptionViewUpdateLablesMultiline()
    if UserDefaults.standard.bool(forKey: "newPrescriptionAdded") {
      return
    }
   
    Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(self.afterThreeSecondsNewPrescriptionViewApperies), userInfo: nil, repeats: false)
  }
  
  func newPrescriptionPopUp(isAvaliable: Bool = false) {
    notFountPrescriptionConstrain.isActive = !isAvaliable
    newPrescriptionFoundConstrain.isActive = isAvaliable
  }
  
  func newPrescriptionViewCornerRadiusShadow() {
    prescriptionMainView.layer.cornerRadius = 20
  }
  
  
  func prescriptionButtonCornerRadius() {
    addPrescriptionButtonOutlet.layer.cornerRadius = 10
    dontAddPrescriptionButtonOutlet.layer.cornerRadius = 10
  }
  
  func newPrescriptionTableViewRegisterNib() {
    newPrescriptionTableview.register(UINib(nibName: "NewPrescriptionTableViewCell", bundle: nil), forCellReuseIdentifier: "NewPrescriptionTableViewCell")
  }
  
  @IBAction func addPrescriptionButtonAction(_ sender: Any) {
    medicineDataModel.medicineArray.insert(MedicinesViewModel(id: 1, title: "Fancy Medication", subTitle: "160mg oral tablet", prescription: "Dr.Judy Jones on July 21,2022", date: "31/01/2023", address: "Pharmacy Name on Jan 31 ,2023, 3170 Abrams Drive Twinsburg,Ohio,44087" , notes: "General tablet4444", condition: "Every Day Morning 444"), at: 0)
    MedicineDataManager.shared.updateselectedMedInformation(updateMedInfo: medicineDataModel.medicineArray)
    newPrescriptionViewAnimation(isActive: false, prescriptionviewY: -200, scrollViewMainViewY: 191, toastDispaly: true)
    reloadTableViewData()
  }
  
  @objc func reloadTableViewData() {
    addMedsTableview.reloadData()
    tableviewHeightAnchor.constant = addMedsTableview.contentSizeHeight
  }
  
  @IBAction func dontAddPrescriptionButtonAction(_ sender: Any) {
    UserDefaults.standard.set(true, forKey: "newPrescriptionAdded")
    newPrescriptionViewAnimation(isActive: false, prescriptionviewY: -200, scrollViewMainViewY: 191)
  }
  
  
  func tableViewRegisterNib() {
    addMedsTableview.register(UINib(nibName: "ListOfAddMedicationTableViewCell", bundle: nil), forCellReuseIdentifier: "ListOfAddMedicationTableViewCell")
  }
  
  override func viewDidLayoutSubviews() {
    tableviewHeightAnchor.constant = addMedsTableview.contentSizeHeight
    newPrescriptionTableviewHeightConstrain.constant = newPrescriptionTableview.contentSizeHeight
  }
  
    @IBAction func addMedsAction(_ sender: Any) {
        ActivityIndicator.showActivityIndicator(uiView: self.view)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            ActivityIndicator.hideActivityIndicator(uiView: self.view)
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            if let addMedsViewController = storyboard.instantiateViewController(withIdentifier: "AddMedsViewController") as? AddMedsViewController {
                addMedsViewController.medDetailDelegate = self
                self.navigationController?.pushViewController(addMedsViewController, animated: true)
            }
        }
    }
}

extension MedsViewController: UITableViewDelegate, UITableViewDataSource {
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if tableView == addMedsTableview {
      return medicineDataModel.medicineArray.count
    } else {
      return  1
    }
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    if tableView == addMedsTableview {
      let cell = tableView.dequeueReusableCell(withIdentifier: "ListOfAddMedicationTableViewCell") as? ListOfAddMedicationTableViewCell
      cell?.addMedsHeaderTitle.text = medicineDataModel.medicineArray[indexPath.row].title
      cell?.addMedsDescrptionLabel.text = medicineDataModel.medicineArray[indexPath.row].subTitle
      cell?.addMedsBGView.backgroundColor = AnthemColor.colorFromHex("#F9FAFB")
      cell?.addMedsBGView.layer.cornerRadius = 15
      return cell!
    } else {
      let cell = tableView.dequeueReusableCell(withIdentifier: "NewPrescriptionTableViewCell") as? NewPrescriptionTableViewCell
      cell?.buttonWidthConstraint.constant = 0
      return cell!
    }
  }
  
  func  tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    if tableView == addMedsTableview {
      let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
      if let medicationDetailsViewController = storyboard.instantiateViewController(withIdentifier: "MedicationDetailsViewController") as? MedicationDetailsViewController {
        medicationDetailsViewController.selectedIndex = indexPath.row
        medicationDetailsViewController.delegate = self
        medicationDetailsViewController.modalPresentationStyle = .fullScreen
        self.navigationController?.present(medicationDetailsViewController, animated: true)
      }
    }
  }
}

extension UITableView {
  var contentSizeHeight: CGFloat {
    var height = CGFloat(0)
    for section in 0..<numberOfSections {
      height = height + rectForHeader(inSection: section).height
      let rows = numberOfRows(inSection: section)
      for row in 0..<rows {
        height = height + rectForRow(at: IndexPath(row: row, section: section)).height
      }
    }
    return height
  }
}

extension MedsViewController: MedsDetailProtocal, AddReminderTimeSelectionProtocol {
  func userDeletedItem(info: String,medArray : [MedicinesViewModel]) {
      var computedString = ""
      if info.count > 16{
          computedString = info.prefix(16) + ".."
      }
      else{
          computedString = info
      }
    showToast(message: "\(computedString) was removed", fontSize: 16)
    medicineDataModel.medicineArray = medArray
    updateYourMedicationLabelText()
    addMedsTableview.reloadData()
  }
    
    func didSelectTime(hour: Int, minute: Int) {
        NotificationTimeComponent.hour = hour
        NotificationTimeComponent.minute = minute
       
    }
}

extension MedsViewController : AddMedsDetailProtocal {
  func selected(info: Int, title: String, moreThanOne: Bool) {
    if moreThanOne {
      self.showToast(message: "\(info) Medications Added")
    } else {
        var computedString = ""
        if title.count > 20{
            computedString = title.prefix(20) + ".."
        }
        else{
            computedString = title
        }
      self.showToast(message: "\(computedString) Added")
    }
  }
}

