//
//  UpdateEmailModel.swift
//  WHE
//
//  Created by Rajesh Gaddam on 20/03/23.
//

import Foundation
struct UpdateEmailModel {
    var updateEmailID: String?
}
