//
//  ValidateEmailModel.swift
//  WHE
//
//  Created by Rajesh Gaddam on 20/03/23.
//

import Foundation
struct ValidateEmailModel {
    var validateEmail: [String : String] = [:]
    var pingDeviceId: String?
    var pingRiskId: String?
    var pingUserId: String?
    var token: String?
}
