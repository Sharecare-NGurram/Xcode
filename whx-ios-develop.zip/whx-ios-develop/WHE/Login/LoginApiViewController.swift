//
//  LoginApiViewController.swift
//  WHE
//
//  Created by Srikanth General on 16/02/23.
//

import Foundation
import UIKit
import WebKit

class LoginApiViewController: UIViewController {
    
    var webView: WKWebView?
    
    func addWebView() {
        let configuration  = WKWebViewConfiguration()
        configuration.userContentController.add(self, name: "loginWebview")
        self.webView = WKWebView(frame: .zero, configuration: configuration)
        self.webView?.translatesAutoresizingMaskIntoConstraints = false
        self.webView?.allowsLinkPreview = true
        self.webView?.allowsBackForwardNavigationGestures = true
        self.webView?.navigationDelegate = self
        guard let webView = self.webView else {
            return
        }
        webView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leftAnchor.constraint(equalTo: self.view.leftAnchor),
            webView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor),
            webView.rightAnchor.constraint(equalTo: self.view.rightAnchor),
            webView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor),
        ])
        self.view.setNeedsLayout()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: true)
        newPrescrptionUserDataRemove()
        addWebView()
        webView?.load(NSURLRequest(url: NSURL(string: "http://localhost:8080")! as URL) as URLRequest)
        // http://localhost:8080/anthem/login
        
        ApolloClientManager.shared.fetchLoginDetails { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let response):
                if let loginUrl = response.login_url,
                   let newLoginUrl =  NSURL(string: loginUrl.replacingOccurrences(of: "3000", with: "8080")) as? URL {
                    self.webView?.load(NSURLRequest(url: newLoginUrl) as URLRequest)
                    let token = response.access_token
                    LocalStorageManager.setAccessToken(token: token ?? "")
                    return
                }
                
                debugPrint("Empty login url ....")
            case .failure(let error):
                debugPrint("login url fetch error: \(error)")
            }
        }
        
    }
    
    func newPrescrptionUserDataRemove() {
        UserDefaults.standard.removeObject(forKey: "newPrescriptionAdded")
    }
    
    func moveToGetStartedScreen()  {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        if LocalStorageManager.fetchLetsGetStarted() == true {
            let vc = PrivacySB.instantiateViewController(withIdentifier: "PrivacyPolicyViewController") as! PrivacyPolicyViewController
            self.navigationController?.pushViewController(vc, animated: true)
            //      let storyboard = UIStoryboard(name: "Main", bundle: nil)
            //      let tabbar = storyboard.instantiateViewController(withIdentifier: "TabBarViewController")
            //      navigationController?.pushViewController(tabbar, animated: true)
        } else {
            let vc = storyboard.instantiateViewController(withIdentifier: "LetsGetStartedViewController") as! LetsGetStartedViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
    func sucessfulLogin() {
        ApolloClientManager.shared.getConsentDetails { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let response):
                self.moveToGetStartedScreen()
                debugPrint(response)
                
            case .failure(let error):
                debugPrint("Get Consent url fetch error: \(error)")
            }
        }
    }
}

extension LoginApiViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        debugPrint("message: \(message)")
        if let messageBody:NSDictionary = message.body as? NSDictionary{
            debugPrint("messageBody: \(messageBody)")
        }
    }
}


extension LoginApiViewController: WKNavigationDelegate{
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("page finished load")
    }
    
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        print("didReceiveServerRedirectForProvisionalNavigation: \(navigation.debugDescription)")
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("didStartProvisionalNavigation")
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url,
           url.absoluteString == "http://localhost:3000/api/anthem/login/success" {
//           url.absoluteString == "http://localhost:8080/api/anthem/login/success" {
            self.sucessfulLogin()
        }
        
        if (navigationAction.navigationType == .linkActivated){
            decisionHandler(.cancel)
        } else {
            decisionHandler(.allow)
        }
    }
}
